object MyApp extends App {
  println("hello world")
}